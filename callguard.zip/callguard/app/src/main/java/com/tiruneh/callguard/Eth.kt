package com.tiruneh.callguard

import java.util.Calendar

/** የኢትዮጵያ ቀንና ሰዓት አቆጣጠር */
object Eth {
    private val months = arrayOf("መስከረም", "ጥቅምት", "ኅዳር", "ታኅሣሥ", "ጥር", "የካቲት", "መጋቢት", "ሚያዝያ", "ግንቦት", "ሰኔ", "ሐምሌ", "ነሐሴ", "ጳጉሜን")

    private fun g2j(y0: Int, m0: Int, d: Int): Int {
        val a = (14 - m0) / 12
        val y = y0 + 4800 - a
        val m = m0 + 12 * a - 3
        return d + (153 * m + 2) / 5 + 365 * y + y / 4 - y / 100 + y / 400 - 32045
    }

    fun format(t: Long): String {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        val j = g2j(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
        val r = (j - 1723856) % 1461
        val n = r % 365 + 365 * (r / 1460)
        val year = 4 * ((j - 1723856) / 1461) + r / 365 - r / 1460
        val month = n / 30 + 1
        val day = n % 30 + 1
        val h = c.get(Calendar.HOUR_OF_DAY)
        val eh = ((h + 6) % 12).let { if (it == 0) 12 else it }
        val part = when { h < 6 -> "ሌሊት"; h < 12 -> "ጠዋት"; h < 18 -> "ቀን"; else -> "ማታ" }
        return "${months[month - 1]} $day $year · $eh:${"%02d".format(c.get(Calendar.MINUTE))} $part"
    }
}
