package com.tiruneh.callguard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("callguard", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = p.getBoolean("enabled", true)
        set(v) { p.edit().putBoolean("enabled", v).apply() }
    var dest: String
        get() = p.getString("dest", "") ?: ""
        set(v) { p.edit().putString("dest", v.trim()).apply() }
    var allowContacts: Boolean
        get() = p.getBoolean("allowContacts", false)
        set(v) { p.edit().putBoolean("allowContacts", v).apply() }
    var notify: Boolean
        get() = p.getBoolean("notify", true)
        set(v) { p.edit().putBoolean("notify", v).apply() }

    fun lastSms(num: String): Long = p.getLong("sms_$num", 0L)
    fun setLastSms(num: String, t: Long) { p.edit().putLong("sms_$num", t).apply() }

    fun addLog(t: Long, num: String, name: String, smsSent: Boolean) {
        val arr = JSONArray(p.getString("log", "[]"))
        val out = JSONArray()
        out.put(JSONObject().put("t", t).put("n", num).put("name", name).put("sms", smsSent))
        for (i in 0 until minOf(arr.length(), 199)) out.put(arr.get(i))
        p.edit().putString("log", out.toString()).apply()
    }
    fun logs(): List<JSONObject> {
        val arr = JSONArray(p.getString("log", "[]"))
        return (0 until arr.length()).map { arr.getJSONObject(it) }
    }
    fun clearLog() { p.edit().putString("log", "[]").apply() }
}
