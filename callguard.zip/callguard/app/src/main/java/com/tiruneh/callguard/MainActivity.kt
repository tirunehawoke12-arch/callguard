package com.tiruneh.callguard

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.telephony.SmsManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val teal = Color.parseColor("#0f8b8d")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs(this)
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#f4f6f8")) }
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(24), dp(16), dp(40)) }
        sv.addView(root)
        setContentView(sv)
    }

    override fun onResume() { super.onResume(); build() }

    private fun hasRole(): Boolean =
        getSystemService(RoleManager::class.java).isRoleHeld(RoleManager.ROLE_CALL_SCREENING)
    private fun hasSms() = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(Color.WHITE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
    }
    private fun text(s: String, size: Float = 14f, bold: Boolean = false, color: Int = Color.parseColor("#16202a")) =
        TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD); setPadding(0, dp(3), 0, dp(3)) }
    private fun button(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s; setTextColor(Color.WHITE); setBackgroundColor(teal); isAllCaps = false
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
        setOnClickListener { onClick() }
    }
    private fun switchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) = Switch(this).apply {
        text = label; isChecked = checked; textSize = 15f; setPadding(0, dp(8), 0, dp(8))
        setOnCheckedChangeListener { _, v -> onChange(v) }
    }

    private fun build() {
        root.removeAllViews()
        root.addView(text("📵 ጥሪ ጠባቂ", 22f, true))
        root.addView(text("ሰው ሲደውልልዎ ስልክዎ አይጠራም፤ ማን እንደደወለ በ SMS ይደርስዎታል።", 13f, color = Color.GRAY))

        // ---- ሁኔታ ----
        val st = card()
        val roleOk = hasRole(); val smsOk = hasSms(); val destOk = prefs.dest.isNotBlank()
        st.addView(text("ዝግጅት", 16f, true))
        st.addView(text((if (roleOk) "✅" else "⬜") + " ጥሪ ማጣራት (ዋና ፈቃድ)"))
        st.addView(text((if (smsOk) "✅" else "⬜") + " SMS መላክ ፈቃድ"))
        st.addView(text((if (destOk) "✅" else "⬜") + " SMS የሚደርስበት ቁጥር"))
        if (!roleOk) st.addView(button("1. ጥሪ ጠባቂን እንደ ጥሪ ማጣሪያ አድርግ") {
            try { startActivityForResult(getSystemService(RoleManager::class.java).createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 1) }
            catch (e: Exception) { Toast.makeText(this, "ቅንብር አልተከፈተም: Settings → Apps → Default apps → Caller ID & spam", Toast.LENGTH_LONG).show() }
        })
        if (!smsOk) st.addView(button("2. SMS እና ሌሎች ፈቃዶች ስጥ") {
            val p = mutableListOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 2)
        })
        root.addView(st)

        // ---- ቅንብር ----
        val cfg = card()
        cfg.addView(text("ቅንብር", 16f, true))
        cfg.addView(switchRow("ጥሪ ጠባቂ ይሰራ", prefs.enabled) { prefs.enabled = it })
        cfg.addView(text("SMS የሚላክበት ቁጥር (የራስዎ ወይም የሌላ ስልክ)", 13f, color = Color.GRAY))
        val et = EditText(this).apply {
            setText(prefs.dest); hint = "ለምሳሌ 0911223344"; inputType = InputType.TYPE_CLASS_PHONE
        }
        cfg.addView(et)
        cfg.addView(button("ቁጥሩን አስቀምጥ") {
            prefs.dest = et.text.toString(); Toast.makeText(this, "ተቀምጧል", Toast.LENGTH_SHORT).show(); build()
        })
        cfg.addView(button("የሙከራ SMS ላክ") {
            prefs.dest = et.text.toString()
            if (!hasSms()) Toast.makeText(this, "መጀመሪያ SMS ፈቃድ ይስጡ", Toast.LENGTH_SHORT).show()
            else if (prefs.dest.isBlank()) Toast.makeText(this, "ቁጥር ያስገቡ", Toast.LENGTH_SHORT).show()
            else try {
                val sm = if (Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                sm.sendMultipartTextMessage(prefs.dest, null, sm.divideMessage("📵 ጥሪ ጠባቂ: የሙከራ መልእክት።\n" + Eth.format(System.currentTimeMillis())), null, null)
                Toast.makeText(this, "ተልኳል። ከደረሰ ሁሉ ነገር ትክክል ነው።", Toast.LENGTH_LONG).show()
            } catch (e: Exception) { Toast.makeText(this, "መላክ አልተቻለም: ${e.message}", Toast.LENGTH_LONG).show() }
        })
        cfg.addView(switchRow("በስልኬ ውስጥ ያሉ ሰዎች (Contacts) ይጥሩ", prefs.allowContacts) { prefs.allowContacts = it })
        cfg.addView(switchRow("ድምጽ የሌለው ማሳወቂያ አሳይ", prefs.notify) { prefs.notify = it })
        root.addView(cfg)

        // ---- መዝገብ ----
        val lg = card()
        val logs = prefs.logs()
        lg.addView(text("የተዘጉ ጥሪዎች (${logs.size})", 16f, true))
        if (logs.isEmpty()) lg.addView(text("እስካሁን የለም", 13f, color = Color.GRAY))
        for (o in logs.take(50)) {
            val who = if (o.getString("name").isNotBlank()) "${o.getString("name")} (${o.getString("n")})" else o.getString("n")
            lg.addView(text("$who\n${Eth.format(o.getLong("t"))} · " + (if (o.getBoolean("sms")) "SMS ተልኳል" else "SMS አልተላከም"), 13f))
        }
        if (logs.isNotEmpty()) lg.addView(button("መዝገቡን አጽዳ") { prefs.clearLog(); build() })
        root.addView(lg)

        root.addView(text("ማሳሰቢያ: ጥሪው ለደዋዩ «ተዘግቷል/ስራ በዝቶበታል» ሆኖ ይሰማዋል። SMS ሲላክ የስልክ ኩባንያው ክፍያ ሊያስከፍል ይችላል። ተመሳሳይ ደዋይ በ2 ደቂቃ ውስጥ ደጋግሞ ቢደውል አንድ SMS ብቻ ይላካል።", 12f, color = Color.GRAY))
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(c, p, r); build() }
}
