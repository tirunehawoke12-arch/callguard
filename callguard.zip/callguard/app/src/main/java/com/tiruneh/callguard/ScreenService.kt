package com.tiruneh.callguard

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.telecom.Call
import android.telecom.CallScreeningService
import android.telephony.SmsManager

class ScreenService : CallScreeningService() {

    override fun onScreenCall(details: Call.Details) {
        val allow = CallScreeningService.CallResponse.Builder().build()
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) { respondToCall(details, allow); return }
        val prefs = Prefs(this)
        if (!prefs.enabled) { respondToCall(details, allow); return }

        val num = details.handle?.schemeSpecificPart ?: ""
        val name = lookupName(num)
        if (prefs.allowContacts && name != null) { respondToCall(details, allow); return }

        // ጥሪውን በዝምታ ዝጋ: አይጠራም፣ በ"ያመለጠ ጥሪ" ማሳወቂያም አይረብሽም
        respondToCall(details, CallScreeningService.CallResponse.Builder()
            .setDisallowCall(true)
            .setRejectCall(true)
            .setSkipNotification(true)
            .build())

        val now = System.currentTimeMillis()
        val shown = if (num.isBlank()) "ያልታወቀ ቁጥር" else num
        val label = if (name != null) "$name ($shown)" else shown
        var sent = false
        // ተደጋጋሚ ጥሪ ከሆነ በ2 ደቂቃ ውስጥ አንድ SMS ብቻ (ክፍያ እንዳይበዛ)
        if (prefs.dest.isNotBlank() && now - prefs.lastSms(num) > 120_000) {
            sent = sendSms(prefs.dest, "📵 ጥሪ ጠባቂ: $label ደውሎልዎት ነበር።\n${Eth.format(now)}")
            if (sent) prefs.setLastSms(num, now)
        }
        prefs.addLog(now, shown, name ?: "", sent)
        if (prefs.notify) notifyBlocked(label, now)
    }

    private fun sendSms(to: String, text: String): Boolean = try {
        val sm = if (android.os.Build.VERSION.SDK_INT >= 31) getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sm.sendMultipartTextMessage(to, null, sm.divideMessage(text), null, null)
        true
    } catch (e: Exception) { false }

    private fun lookupName(num: String): String? {
        if (num.isBlank() || checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val uri = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num))
            contentResolver.query(uri, arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        } catch (e: Exception) { null }
    }

    private fun notifyBlocked(label: String, t: Long) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("blocked", "የተዘጉ ጥሪዎች", NotificationManager.IMPORTANCE_LOW))
            val n = Notification.Builder(this, "blocked")
                .setSmallIcon(android.R.drawable.sym_call_missed)
                .setContentTitle("ጥሪ ተዘግቷል")
                .setContentText("$label · ${Eth.format(t)}")
                .setAutoCancel(true).build()
            nm.notify((t % Int.MAX_VALUE).toInt(), n)
        } catch (_: Exception) {}
    }
}
