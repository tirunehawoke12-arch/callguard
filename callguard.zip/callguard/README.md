# ጥሪ ጠባቂ (CallGuard)
ሰው ሲደውል ስልኩ አይጠራም (በዝምታ ይዘጋል)፤ ማን እንደደወለ SMS ይላካል።
APK: GitHub Actions → "Build APK" → Artifacts → CallGuard-apk.
ከጫኑ በኋላ: መተግበሪያውን ክፈት → 1) ጥሪ ማጣሪያ አድርግ 2) ፈቃዶች ስጥ 3) ቁጥር አስገባ → ሙከራ SMS ላክ።
